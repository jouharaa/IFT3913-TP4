package test.tache1;

import org.junit.jupiter.api.Test;

import currencyConverter.Currency;
import currencyConverter.MainWindow;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class MainWindowTest1 {

    // Test de conversion valide pour différentes devises et montants
    @Test
    public void testValidConversion() {
        ArrayList<Currency> currencies = Currency.init();
        double validAmount = 500.0;
        String[] currenciesToTest = {"USD", "CAD", "GBP", "EUR", "CHF", "AUD"};

        for (String fromCurrency : currenciesToTest) {
            for (String toCurrency : currenciesToTest) {
                if (!fromCurrency.equals(toCurrency)) {
                    double result = MainWindow.convert(fromCurrency, toCurrency, currencies, validAmount);
                    assertNotNull(result);
                }
            }
        }
    }

    // Test pour les montants aux limites specifiées 
    @Test
    public void testBoundaryAmounts() {
        ArrayList<Currency> currencies = Currency.init();
        double lowerBoundary = 0.0;
        double upperBoundary = 1000000.0;

        double resultLower = MainWindow.convert("USD", "EUR", currencies, lowerBoundary);
        assertNotNull(resultLower);

        double resultUpper = MainWindow.convert("USD", "EUR", currencies, upperBoundary);
        assertNotNull(resultUpper);
    }

    // Test pour les montants en dehors de la plage valide
    @Test
    public void testInvalidAmounts() {
        ArrayList<Currency> currencies = Currency.init();
        
        // Test avec un montant négatif
        double resultNegative = MainWindow.convert("USD", "EUR", currencies, -100.0);
        assertEquals(0.0, resultNegative); 

        // Test avec un montant supérieur à la limite
        double resultAboveUpper = MainWindow.convert("USD", "EUR", currencies, 1000001.0);
        assertEquals(0.0, resultAboveUpper); 
    }
}

 