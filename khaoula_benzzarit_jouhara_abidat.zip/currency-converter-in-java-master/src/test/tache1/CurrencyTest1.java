package test.tache1;

import org.junit.jupiter.api.Test;

import currencyConverter.Currency;

import static org.junit.jupiter.api.Assertions.*;

public class CurrencyTest1 {

    // Test de conversion valide
    @Test
    public void testValidConversion() {
        double amount = 500.0;
        double exchangeRate = 0.93;

        double result = Currency.convert(amount, exchangeRate);
        assertEquals(465.0, result, 0.01);
    }

    // Test avec des montants négatifs ou nuls
    @Test
    public void testInvalidConversion() {
        double invalidAmount = -100.0;
        double exchangeRate = 0.93;

        double resultNegative = Currency.convert(invalidAmount, exchangeRate);
        assertTrue(resultNegative <= 0);

        invalidAmount = 0.0;
        double resultZero = Currency.convert(invalidAmount, exchangeRate);
        assertEquals(0.0, resultZero, 0.01);
    }
}
