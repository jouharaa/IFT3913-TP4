Places vos tests ici. Utilisation de JUnit5 requise.
// Boite noire 
package test.tache1;

import org.junit.jupiter.api.Test;

import currencyConverter.Currency;

import static org.junit.jupiter.api.Assertions.*;

public class CurrencyTest1 {

    // Test de conversion valide
    @Test
    public void testValidConversion() {
        double amount = 500.0;
        double exchangeRate = 0.93;

        double result = Currency.convert(amount, exchangeRate);
        assertEquals(465.0, result, 0.01);
    }

    // Test avec des montants négatifs ou nuls
    @Test
    public void testInvalidConversion() {
        double invalidAmount = -100.0;
        double exchangeRate = 0.93;

        double resultNegative = Currency.convert(invalidAmount, exchangeRate);
        assertTrue(resultNegative <= 0);

        invalidAmount = 0.0;
        double resultZero = Currency.convert(invalidAmount, exchangeRate);
        assertEquals(0.0, resultZero, 0.01);
    }
}

package test.tache1;

import org.junit.jupiter.api.Test;

import currencyConverter.Currency;
import currencyConverter.MainWindow;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class MainWindowTest1 {

    // Test de conversion valide pour différentes devises et montants
    @Test
    public void testValidConversion() {
        ArrayList<Currency> currencies = Currency.init();
        double validAmount = 500.0;
        String[] currenciesToTest = {"USD", "CAD", "GBP", "EUR", "CHF", "AUD"};

        for (String fromCurrency : currenciesToTest) {
            for (String toCurrency : currenciesToTest) {
                if (!fromCurrency.equals(toCurrency)) {
                    double result = MainWindow.convert(fromCurrency, toCurrency, currencies, validAmount);
                    assertNotNull(result);
                }
            }
        }
    }

    // Test pour les montants aux limites specifiées 
    @Test
    public void testBoundaryAmounts() {
        ArrayList<Currency> currencies = Currency.init();
        double lowerBoundary = 0.0;
        double upperBoundary = 1000000.0;

        double resultLower = MainWindow.convert("USD", "EUR", currencies, lowerBoundary);
        assertNotNull(resultLower);

        double resultUpper = MainWindow.convert("USD", "EUR", currencies, upperBoundary);
        assertNotNull(resultUpper);
    }

    // Test pour les montants en dehors de la plage valide
    @Test
    public void testInvalidAmounts() {
        ArrayList<Currency> currencies = Currency.init();
        
        // Test avec un montant négatif
        double resultNegative = MainWindow.convert("USD", "EUR", currencies, -100.0);
        assertEquals(0.0, resultNegative); 

        // Test avec un montant supérieur à la limite
        double resultAboveUpper = MainWindow.convert("USD", "EUR", currencies, 1000001.0);
        assertEquals(0.0, resultAboveUpper); 
    }
}

// Boite blanc
package test.tache2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import currencyConverter.Currency;
import currencyConverter.MainWindow;

public class CurrencyTest2 {

    // couverture des instructions
    @Test
    public void testCurrencyConvertWithValidData() {
        double result = Currency.convert(100.0, 1.5);
        assertEquals(150.0, result);
    }

    // couverture des arcs du graphe de flot de contrôle
    @Test
    public void testCurrencyConvertZeroRate() {
        double result = Currency.convert(100.0, 0.0);
        assertEquals(0.0, result);
    }
    
    // couverture des chemins indépendants du graphe de flot de contrôle 
    @Test
    public void testCurrencyConvertNegativeAmount() {
        double result = Currency.convert(-100.0, 1.5);
        assertEquals(-150.0, result); 
    }

    // couverture des conditions
    @Test
    public void testConvertWithZeroAndNegativeAmount() {
    ArrayList<Currency> currencies = Currency.init();
    double zeroAmountResult = MainWindow.convert("USD", "EUR", currencies, 0.0);
    double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);

    assertNotNull(zeroAmountResult);
    assertEquals(0.0, negativeAmountResult); 
    }

    // couverture des i-chemins
    @Test
    public void testConvertVariousScenarios() {
    ArrayList<Currency> currencies = Currency.init();
    // avec montants et devises valides
    double validResult = MainWindow.convert("USD", "EUR", currencies, 100.0);

    // avec devise invalide
    double invalidCurrencyResult = MainWindow.convert("InvalidCurrency", "EUR", currencies, 100.0);

    // avec montant négatif
    double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);

    assertNotNull(validResult);
    assertEquals(0.0, invalidCurrencyResult); 
    assertEquals(0.0, negativeAmountResult); 
    }

}

package test.tache2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import currencyConverter.MainWindow;
import currencyConverter.Currency;

public class MainWindowTest2 {

    // couverture des instructions
    @Test
    public void testConvertValidInputs() {
        ArrayList<Currency> currencies = Currency.init();
        double result = MainWindow.convert("USD", "EUR", currencies, 500.0);
        assertNotNull(result);
    }

    // couverture des arcs du graphe de flot de contrôle
    @Test
    public void testConvertWithInvalidCurrency() {
        ArrayList<Currency> currencies = Currency.init();
        double result = MainWindow.convert("InvalidCurrency", "EUR", currencies, 500.0);
        assertEquals(0.0, result); 
    }

    // couverture des chemins indépendants du graphe de flot de contrôle
    @Test
    public void testConvertWithBoundaryValues() {
        ArrayList<Currency> currencies = Currency.init();
        double resultWithZero = MainWindow.convert("USD", "EUR", currencies, 0.0);
        double resultWithMax = MainWindow.convert("USD", "EUR", currencies, 1000000.0);

        assertNotNull(resultWithZero);
        assertNotNull(resultWithMax);
    }

    // couverture des conditions
    @Test
    public void testConvertWithZeroAndNegativeAmount() {
        ArrayList<Currency> currencies = Currency.init();
        double zeroAmountResult = MainWindow.convert("USD", "EUR", currencies, 0.0);
        double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);
    
        assertNotNull(zeroAmountResult);
        assertEquals(0.0, negativeAmountResult); 
    }

    // couverture des i-chemins
    @Test
    public void testConvertVariousScenarios() {
        ArrayList<Currency> currencies = Currency.init();
        // avec montants et devises valides
        double validResult = MainWindow.convert("USD", "EUR", currencies, 100.0);
    
        // avec devise invalide
        double invalidCurrencyResult = MainWindow.convert("InvalidCurrency", "EUR", currencies, 100.0);
    
        // avec montant négatif
        double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);
    
        assertNotNull(validResult);
        assertEquals(0.0, invalidCurrencyResult);
        assertEquals(0.0, negativeAmountResult); 
    }
}       

