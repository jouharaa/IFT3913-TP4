package test.tache2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import currencyConverter.Currency;
import currencyConverter.MainWindow;

public class CurrencyTest2 {

    // couverture des instructions
    @Test
    public void testCurrencyConvertWithValidData() {
        double result = Currency.convert(100.0, 1.5);
        assertEquals(150.0, result);
    }

    // couverture des arcs du graphe de flot de contrôle
    @Test
    public void testCurrencyConvertZeroRate() {
        double result = Currency.convert(100.0, 0.0);
        assertEquals(0.0, result);
    }
    
    // couverture des chemins indépendants du graphe de flot de contrôle 
    @Test
    public void testCurrencyConvertNegativeAmount() {
        double result = Currency.convert(-100.0, 1.5);
        assertEquals(-150.0, result); 
    }

    // couverture des conditions
    @Test
    public void testConvertWithZeroAndNegativeAmount() {
    ArrayList<Currency> currencies = Currency.init();
    double zeroAmountResult = MainWindow.convert("USD", "EUR", currencies, 0.0);
    double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);

    assertNotNull(zeroAmountResult);
    assertEquals(0.0, negativeAmountResult); 
    }

    // couverture des i-chemins
    @Test
    public void testConvertVariousScenarios() {
    ArrayList<Currency> currencies = Currency.init();
    // avec montants et devises valides
    double validResult = MainWindow.convert("USD", "EUR", currencies, 100.0);

    // avec devise invalide
    double invalidCurrencyResult = MainWindow.convert("InvalidCurrency", "EUR", currencies, 100.0);

    // avec montant négatif
    double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);

    assertNotNull(validResult);
    assertEquals(0.0, invalidCurrencyResult); 
    assertEquals(0.0, negativeAmountResult); 
    }

}