package test.tache2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import currencyConverter.MainWindow;
import currencyConverter.Currency;

public class MainWindowTest2 {

    // couverture des instructions
    @Test
    public void testConvertValidInputs() {
        ArrayList<Currency> currencies = Currency.init();
        double result = MainWindow.convert("USD", "EUR", currencies, 500.0);
        assertNotNull(result);
    }

    // couverture des arcs du graphe de flot de contrôle
    @Test
    public void testConvertWithInvalidCurrency() {
        ArrayList<Currency> currencies = Currency.init();
        double result = MainWindow.convert("InvalidCurrency", "EUR", currencies, 500.0);
        assertEquals(0.0, result); 
    }

    // couverture des chemins indépendants du graphe de flot de contrôle
    @Test
    public void testConvertWithBoundaryValues() {
        ArrayList<Currency> currencies = Currency.init();
        double resultWithZero = MainWindow.convert("USD", "EUR", currencies, 0.0);
        double resultWithMax = MainWindow.convert("USD", "EUR", currencies, 1000000.0);

        assertNotNull(resultWithZero);
        assertNotNull(resultWithMax);
    }

    // couverture des conditions
    @Test
    public void testConvertWithZeroAndNegativeAmount() {
        ArrayList<Currency> currencies = Currency.init();
        double zeroAmountResult = MainWindow.convert("USD", "EUR", currencies, 0.0);
        double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);
    
        assertNotNull(zeroAmountResult);
        assertEquals(0.0, negativeAmountResult); 
    }

    // couverture des i-chemins
    @Test
    public void testConvertVariousScenarios() {
        ArrayList<Currency> currencies = Currency.init();
        // avec montants et devises valides
        double validResult = MainWindow.convert("USD", "EUR", currencies, 100.0);
    
        // avec devise invalide
        double invalidCurrencyResult = MainWindow.convert("InvalidCurrency", "EUR", currencies, 100.0);
    
        // avec montant négatif
        double negativeAmountResult = MainWindow.convert("USD", "EUR", currencies, -100.0);
    
        assertNotNull(validResult);
        assertEquals(0.0, invalidCurrencyResult);
        assertEquals(0.0, negativeAmountResult); 
    }
}       

